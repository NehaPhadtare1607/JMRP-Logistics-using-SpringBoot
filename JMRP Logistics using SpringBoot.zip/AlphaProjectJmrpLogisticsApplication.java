package com.ty.ALPHA_PROJECT_JMRP_LOGISTICS;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlphaProjectJmrpLogisticsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlphaProjectJmrpLogisticsApplication.class, args);
	}

}
