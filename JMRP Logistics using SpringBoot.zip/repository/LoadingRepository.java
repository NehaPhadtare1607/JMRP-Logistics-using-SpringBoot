package com.ty.ALPHA_PROJECT_JMRP_LOGISTICS.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ty.ALPHA_PROJECT_JMRP_LOGISTICS.entity.Loading;

public interface LoadingRepository extends JpaRepository<Loading, Integer>{

}
